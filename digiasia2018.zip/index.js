$(function(){
    console.log($("#USA_V > li").length)
    
})